var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');


router.route('/:_id').get(function (req, res){
    
    GLOBAL.schemas["Formation"].find(function (err, result){
        if (err) {
            throw err;
        } 
        res.render('detform', {
            title: 'informations',
            formation: result[0]});
    });
});
module.exports = router;